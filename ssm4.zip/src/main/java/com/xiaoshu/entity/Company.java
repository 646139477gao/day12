package com.xiaoshu.entity;

import java.io.Serializable;
import javax.persistence.*;

@Table(name = "p_company")
public class Company implements Serializable {
    @Id
    @Column(name = "cmopany_id")
    private Integer cmopanyId;

    @Column(name = "company_name")
    private String companyName;

    private static final long serialVersionUID = 1L;

    /**
     * @return cmopany_id
     */
    public Integer getCmopanyId() {
        return cmopanyId;
    }

    /**
     * @param cmopanyId
     */
    public void setCmopanyId(Integer cmopanyId) {
        this.cmopanyId = cmopanyId;
    }

    /**
     * @return company_name
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     * @param companyName
     */
    public void setCompanyName(String companyName) {
        this.companyName = companyName == null ? null : companyName.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", cmopanyId=").append(cmopanyId);
        sb.append(", companyName=").append(companyName);
        sb.append("]");
        return sb.toString();
    }
}